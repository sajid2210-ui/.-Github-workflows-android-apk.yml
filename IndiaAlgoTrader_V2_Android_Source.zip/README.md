# India Algo Trader V2 — Android starter with signal alarms

## Included
- Native Kotlin + Jetpack Compose Android app.
- Intraday and swing dashboard, scanner mock-up, and risk calculator.
- High-importance Android notification channel for signal alerts, default notification sound, and vibration.
- Per-signal ALARM test button and dashboard TEST BUY ALARM.
- No broker connection and no order placement.
- Cloud APK build workflow at `.github/workflows/android-apk.yml`.

## Critical limitation
This build still uses demonstration signal rows. It is NOT connected to live NSE prices or a live scanner. Alarm buttons test the phone's notification sound/vibration; they do not detect real market signals yet. A licensed market-data source and signal engine are required before live alerts can be generated.

## Build APK in GitHub Actions
1. Create a GitHub repository from the phone browser.
2. Upload the contents of this project to the repository root (not the enclosing folder).
3. Open the repository's Actions tab and run **Build Android APK** (or push to `main`).
4. Open the successful workflow run, find Artifacts, and download `IndiaAlgoTrader-debug-apk`.
5. Extract the downloaded artifact ZIP and install `app-debug.apk` on Android. Allow installation from that source when Android asks.

The workflow builds a debug APK for testing. For broader distribution, create a signed release build and protect signing keys.
