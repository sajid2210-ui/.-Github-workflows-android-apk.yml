package com.example.indiaalgotrader

import android.os.Bundle
import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B2940)
private val Green = Color(0xFF16A36A)
private val Red = Color(0xFFE05252)
private val Blue = Color(0xFF4C8DFF)

data class Signal(
    val symbol: String, val setup: String, val side: String,
    val entry: Double, val stop: Double, val target1: Double, val target2: Double,
    val timeframe: String, val status: String = "Review"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createSignalChannel(this)
        setContent { IndiaAlgoApp() }
    }
}

private const val SIGNAL_CHANNEL_ID = "trade_signals"

private fun createSignalChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(
            SIGNAL_CHANNEL_ID,
            "Trading signal alarms",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Sound and vibration alerts for BUY and SELL signals"
            enableVibration(true)
            setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI, null)
        }
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}

private fun sendSignalAlarm(context: Context, signal: Signal) {
    createSignalChannel(context)
    val color = if (signal.side == "BUY") android.graphics.Color.rgb(22, 163, 106)
                else android.graphics.Color.rgb(224, 82, 82)
    val notification = NotificationCompat.Builder(context, SIGNAL_CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("${signal.side} signal: ${signal.symbol}")
        .setContentText("Entry ₹${signal.entry} | SL ₹${signal.stop} | T1 ₹${signal.target1} | T2 ₹${signal.target2}")
        .setStyle(NotificationCompat.BigTextStyle().bigText(
            "${signal.setup} (${signal.timeframe})\nEntry ₹${signal.entry}\nStop loss ₹${signal.stop}\nTarget 1 ₹${signal.target1}\nTarget 2 ₹${signal.target2}"
        ))
        .setColor(color)
        .setPriority(NotificationCompat.PRIORITY_MAX)
        .setAutoCancel(true)
        .build()
    if (Build.VERSION.SDK_INT < 33 ||
        context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
        NotificationManagerCompat.from(context).notify(signal.symbol.hashCode(), notification)
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(700, VibrationEffect.DEFAULT_AMPLITUDE))
                else @Suppress("DEPRECATION") vibrator.vibrate(700)
            }
        } catch (_: Exception) { }
    }
}

@Composable
fun IndiaAlgoApp() {
    val context = LocalContext.current
    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    var tab by remember { mutableStateOf("Dashboard") }
    var style by remember { mutableStateOf("Intraday") }
    var capital by remember { mutableStateOf("50000") }
    var maxRisk by remember { mutableStateOf("1") }
    var priceCap by remember { mutableStateOf("500") }
    var search by remember { mutableStateOf("") }
    var approved by remember { mutableStateOf(setOf<String>()) }
    var rejected by remember { mutableStateOf(setOf<String>()) }

    val demoSignals = remember {
        listOf(
            Signal("RELIANCE", "Range breakout + volume", "BUY", 1468.0, 1449.0, 1496.0, 1515.0, "15m"),
            Signal("SBIN", "VWAP reclaim + EMA trend", "BUY", 842.0, 831.0, 858.0, 869.0, "5m"),
            Signal("TATASTEEL", "Resistance rejection", "SELL", 162.5, 165.2, 158.4, 155.8, "15m"),
            Signal("IRFC", "Consolidation breakout", "BUY", 126.0, 122.8, 130.8, 134.0, "1D")
        )
    }
    val visible = demoSignals.filter { it.symbol.contains(search, true) }
    val riskCash = (capital.toDoubleOrNull() ?: 0.0) * ((maxRisk.toDoubleOrNull() ?: 1.0) / 100.0)

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Blue,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Navy, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Dashboard", "Scanner", "Risk", "Settings").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item },
                        icon = { Text(when(item) { "Dashboard" -> "⌂"; "Scanner" -> "⌕"; "Risk" -> "◎"; else -> "⚙" }) },
                        label = { Text(item) })
                }
            }
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text("INDIA ALGO TRADER", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Text("Manual execution • NSE cash market", color = Color.LightGray, fontSize = 12.sp)
                        }
                        Surface(color = Color(0xFF5A3D18), shape = RoundedCornerShape(20.dp)) {
                            Text("DEMO DATA", color = Color(0xFFFFD18A), modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                when (tab) {
                    "Dashboard" -> {
                        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricCard("Mode", style, Modifier.weight(1f))
                            MetricCard("Risk / trade", "₹${"%.0f".format(riskCash)}", Modifier.weight(1f))
                        } }
                        item { Text("Trading mode", fontWeight = FontWeight.SemiBold) }
                        item { ModePicker(style) { style = it } }
                        item { Text("Signal overview", fontWeight = FontWeight.SemiBold) }
                        item {
                            Button(
                                onClick = { sendSignalAlarm(context, demoSignals.first()) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("TEST BUY ALARM") }
                        }
                        item { Text("Signals below are illustrative examples only. No live NSE feed is connected. Alarm test verifies phone notification and vibration.", color = Color(0xFFFFC66D), fontSize = 12.sp) }
                        items(visible) { signal ->
                            SignalCard(signal, onAlarm = { sendSignalAlarm(context, signal) },
                                approved = signal.symbol in approved,
                                rejected = signal.symbol in rejected,
                                onApprove = { approved = approved + signal.symbol; rejected = rejected - signal.symbol },
                                onReject = { rejected = rejected + signal.symbol; approved = approved - signal.symbol })
                        }
                    }
                    "Scanner" -> {
                        item { Text("Stock scanner", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        item { OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Search symbol") }, modifier = Modifier.fillMaxWidth()) }
                        item { Text("Planned scan rules", fontWeight = FontWeight.SemiBold) }
                        item { InfoCard("Intraday", "5m / 15m candles • VWAP • EMA 9/21 • RSI • relative volume • opening range breakout") }
                        item { InfoCard("Swing", "1D / 1h trend • EMA 21/55 • RSI • consolidation • breakout close • volume expansion") }
                        item { InfoCard("Universe", "Nifty 200 / Nifty 500; configurable price filter and liquidity filter") }
                        item { Text("Signal list", fontWeight = FontWeight.SemiBold) }
                        items(visible) { signal -> SignalCard(signal, onAlarm = { sendSignalAlarm(context, signal) }, approved = signal.symbol in approved, rejected = signal.symbol in rejected, onApprove = { approved = approved + signal.symbol }, onReject = { rejected = rejected + signal.symbol }) }
                    }
                    "Risk" -> {
                        item { Text("Risk management", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        item { OutlinedTextField(value = capital, onValueChange = { capital = it.filter(Char::isDigit) }, label = { Text("Trading capital (₹)") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(value = maxRisk, onValueChange = { maxRisk = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Risk per trade (%)") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(value = priceCap, onValueChange = { priceCap = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Maximum stock price (₹)") }, modifier = Modifier.fillMaxWidth()) }
                        item { MetricCard("Maximum planned loss per trade", "₹${"%.2f".format(riskCash)}", Modifier.fillMaxWidth()) }
                        item { InfoCard("Position sizing", "Quantity = risk amount ÷ (entry price − stop-loss price). Round down to whole shares. Validate lot size for derivatives.") }
                        item { InfoCard("Safety rule", "No order is placed by this app. Check liquidity, spread, circuit limits and the live price before manually placing any trade.") }
                    }
                    else -> {
                        item { Text("Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        item { InfoCard("Broker", "Not connected and not required. You place every order yourself in your broker app.") }
                        item { InfoCard("Market data", "Live NSE data provider is not connected in this starter build. Add a licensed market-data API before relying on live alerts.") }
                        item { InfoCard("Supported workflows", "Intraday and 5–10 day swing-trade research. Signals require confirmation; this is not investment advice.") }
                        item { Text("Price filter currently set to ₹${priceCap.ifBlank { "500" }}", color = Color.LightGray) }
                    }
                }
            }
        }
    }
}

@Composable
fun ModePicker(value: String, onChange: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Intraday", "Swing").forEach { mode ->
            FilterChip(selected = value == mode, onClick = { onChange(mode) }, label = { Text(mode) })
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Color.LightGray, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(body, color = Color(0xFFD0D7E2), fontSize = 13.sp)
        }
    }
}

@Composable
fun SignalCard(signal: Signal, onAlarm: () -> Unit, approved: Boolean, rejected: Boolean, onApprove: () -> Unit, onReject: () -> Unit) {
    val sideColor = if (signal.side == "BUY") Green else Red
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text(signal.symbol, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("${signal.setup} • ${signal.timeframe}", color = Color.LightGray, fontSize = 11.sp)
                }
                Surface(color = sideColor.copy(alpha = 0.18f), shape = RoundedCornerShape(20.dp)) {
                    Text(signal.side, color = sideColor, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontWeight = FontWeight.Bold)
                }
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                PriceCell("Entry", signal.entry, Color.White)
                PriceCell("Stop loss", signal.stop, Red)
                PriceCell("Target 1", signal.target1, Green)
                PriceCell("Target 2", signal.target2, Green)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onAlarm, modifier = Modifier.weight(1f)) { Text("ALARM") }
                Button(onClick = onApprove, modifier = Modifier.weight(1f), enabled = !approved && !rejected, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(if (approved) "Marked" else "Review / Approve") }
                OutlinedButton(onClick = onReject, modifier = Modifier.weight(1f), enabled = !approved && !rejected) { Text(if (rejected) "Rejected" else "Dismiss") }
            }
            if (approved) Text("Approved for your manual review — no order was sent.", color = Color(0xFF7CE0AE), fontSize = 11.sp)
            if (rejected) Text("Signal dismissed.", color = Color.LightGray, fontSize = 11.sp)
        }
    }
}

@Composable
fun PriceCell(label: String, price: Double, color: Color) {
    Column {
        Text(label, color = Color.LightGray, fontSize = 9.sp)
        Text("₹${"%.2f".format(price)}", color = color, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
    }
}
